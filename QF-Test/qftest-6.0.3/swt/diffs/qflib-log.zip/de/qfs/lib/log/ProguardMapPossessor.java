// {{{ copyright

/********************************************************************
 *
 * Copyright (C) 2016 Quality First Software
 * All rights reserved
 *
 *******************************************************************/

// }}}

package de.qfs.lib.log;

public interface ProguardMapPossessor {
    public ProguardMap getProguardMap();
    public void setProguardMap(final ProguardMap proguardMap);
}
